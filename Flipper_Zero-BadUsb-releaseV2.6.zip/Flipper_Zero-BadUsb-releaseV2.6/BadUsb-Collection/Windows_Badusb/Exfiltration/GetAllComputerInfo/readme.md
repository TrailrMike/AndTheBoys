
# GetAllComputerInfo
This script saves almost every valuable info about the pc to a file.

## How to use?

This script is not plug and play. You need to do the following changes:

- change path of the file "STRING $Path = "PATH""


## Features

- open powershell 
- exfiltrate pc info
- paste info to a html file



## Feedback

If you have any feedback, please reach out to me via Discord "UNC0V3R3D#8662".






## Support

For support, contact me via  Discord "UNC0V3R3D#8662".


## Meta


- If you want to sponsor me on Patreon, the link is on my profile.


