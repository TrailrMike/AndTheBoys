
# StartWifiAccessPoint

This script sets up a hosted wireless network on a computer running Windows.


## How to use?

This script is not plug and play. You will have to do the following changes:

- choose name of wifi "ssid=WLAN NAME"
- choose password of the wifi "key=PASSWORD"


## Features

- open powershell 
- create new wifi by ssid
- set password for wifi





## Feedback

If you have any feedback, please reach out to me via Discord "UNC0V3R3D#8662".






## Support

For support, contact me via  Discord "UNC0V3R3D#8662".


## Meta


- If you want to sponsor me on Patreon, the link is on my profile.


